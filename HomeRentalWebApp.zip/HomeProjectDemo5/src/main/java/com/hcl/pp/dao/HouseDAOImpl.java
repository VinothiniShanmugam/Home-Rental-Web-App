package com.hcl.pp.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import javax.persistence.Query;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.pp.actions.HousesAppController;
import com.hcl.pp.model.House;



@Transactional
@Repository("houseDAO")
public class HouseDAOImpl implements HouseDAO {

	@Autowired
	private SessionFactory sessionFactory;
	private static Logger logger = (Logger) LogManager.getLogger(HouseDAOImpl.class);

	@Override
	public House getHouseById(long HOUSE_ID) {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createNamedQuery("getHouseById");
		logger.info("House fetched my Id");
		return (House) query.setParameter("id", HOUSE_ID).getSingleResult();
	}

	@Override
	public boolean saveHouse(House house) {
		Session session = sessionFactory.getCurrentSession();
		session.save(house);
		logger.info(house.getName() + " saved");
		return true;
	}

	@Override
	public List<House> fetchAll() {
		Session session = sessionFactory.getCurrentSession();
		logger.info("Houses fetched");
		return session.createNamedQuery("fetchAll").getResultList();
	}

	@Override
	public void deleteHouse(long HOUSE_ID) {
		// TODO Auto-generated method stub
		House house = (House) sessionFactory.getCurrentSession().load(
				House.class, HOUSE_ID);
		if (null != house) {
			this.sessionFactory.getCurrentSession().delete(house);
		}
		
	}

	@Override
	public House updateHouse(House house) {
		sessionFactory.getCurrentSession().update(house);
		return house;
	}

}
