package com.hcl.pp.dao;

import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.pp.actions.HousesAppController;
import com.hcl.pp.model.Admin;
import com.hcl.pp.model.User;

@Transactional
@Repository("adminDAO")
public class AdminDAOImpl implements AdminDAO {
	@Autowired
	private SessionFactory sessionFactory;
	private static Logger logger = (Logger) LogManager.getLogger(HousesAppController.class);

	@Override
	public User addUser(User user) {
		Session session = sessionFactory.getCurrentSession();
		session.persist(user);
		logger.info(user.getUsername() + " added");
		return user;
	}

	@Override
	public User updateUser(User user) {
		logger.info(user.getUsername() + " updated");
		sessionFactory.getCurrentSession().update(user);
		return user;
	}
	
	@Override
	public boolean removeUser(User user) {
		Session session = sessionFactory.getCurrentSession();
		session.get(User.class, user.getId());
		session.remove(user);
		logger.info("User removed");
		return true;
	}
	@Override
	public List<User> listUsers() {
		Session session = sessionFactory.getCurrentSession();
		List<User> users = session.createNamedQuery("listUsers").getResultList();
		logger.debug("Authenticating user");
		return users;
	}

	@Override
	public Admin addAdmin(Admin admin) {
			Session session = sessionFactory.getCurrentSession();
			session.persist(admin);
			logger.info(admin.getUsername() + " added");
			return admin;
		}

	@Override
	public List<Admin> listAdmins() {
			Session session = sessionFactory.getCurrentSession();
			List<Admin> admins = session.createNamedQuery("listAdmins").getResultList();
			logger.debug("Authenticating user");
			return admins;
	}

}
