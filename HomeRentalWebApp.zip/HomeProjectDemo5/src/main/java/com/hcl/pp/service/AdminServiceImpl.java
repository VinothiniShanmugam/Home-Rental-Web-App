package com.hcl.pp.service;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.pp.dao.AdminDAO;
import com.hcl.pp.dao.UserDAO;
import com.hcl.pp.model.Admin;
import com.hcl.pp.model.User;

@Service("adminService")
public class AdminServiceImpl implements AdminService {
	@Autowired
	private AdminDAO adminDAO;
	
	private static Logger logger = (Logger) LogManager.getLogger(UserServiceImpl.class);

	@Override
	public User addUser(User user) {
		logger.info("Adding User");
		return adminDAO.addUser(user);
	}

	@Override
	public User updateUser(User user) {
		logger.warn("Updation by " + user.getUsername());
		return adminDAO.updateUser(user);
	}
	
	@Override
	public boolean removeUser(User user) {
		logger.warn(user.getUsername() + " removed");
		return adminDAO.removeUser(user);
	}

	@Override
	public List<User> listUsers() {
		logger.debug("Fetching list of users");
		return adminDAO.listUsers();
	}
	
	@Override
	public List<Admin> listAdmins() {
			logger.debug("Fetching list of users");
			return adminDAO.listAdmins();
	}

	@Override
	public Admin addAdmin(Admin admin) {
		logger.info("Adding Admin");
		return adminDAO.addAdmin(admin);
		
	}
}
